﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    class Blocks_7 : Blocks//"凸"形方块
    {
        int flag;
        public Blocks_7(Map m)
        {
            Random r = new Random();
            flag = r.Next(0, 4);
            if (flag == 0)
            {
                C_B = 70;
                P[0].X = -2; P[0].Y = m.map.GetLength(1) / 2 - 1;
                P[1].X = -1; P[1].Y = m.map.GetLength(1) / 2 - 2;
                P[2].X = -1; P[2].Y = m.map.GetLength(1) / 2 - 1;
                P[3].X = -1; P[3].Y = m.map.GetLength(1) / 2;
            }
            else if (flag == 1)
            {
                C_B = 71;
                P[0].X = -3; P[0].Y = m.map.GetLength(1) / 2 - 1;
                P[1].X = -2; P[1].Y = m.map.GetLength(1) / 2 - 1;
                P[2].X = -2; P[2].Y = m.map.GetLength(1) / 2;
                P[3].X = -1; P[3].Y = m.map.GetLength(1) / 2 - 1;
            }
            else if (flag == 2)
            {
                C_B = 72;
                P[0].X = -2; P[0].Y = m.map.GetLength(1) / 2 - 2;
                P[1].X = -2; P[1].Y = m.map.GetLength(1) / 2 - 1;
                P[2].X = -2; P[2].Y = m.map.GetLength(1) / 2;
                P[3].X = -1; P[3].Y = m.map.GetLength(1) / 2 - 1;
            }
            else
            {
                C_B = 73;
                P[0].X = -3; P[0].Y = m.map.GetLength(1) / 2 - 1;
                P[1].X = -2; P[1].Y = m.map.GetLength(1) / 2 - 2;
                P[2].X = -2; P[2].Y = m.map.GetLength(1) / 2 - 1;
                P[3].X = -1; P[3].Y = m.map.GetLength(1) / 2 - 1;
            }
        }
        public override bool Can_Revolve(Map m)
        {
            if (flag == 0)
            {
                if (P[3].X == m.map.GetLength(0) - 1)
                    return false;
                if (m.map[P[2].X+1, P[2].Y] == 0)
                    return true;
            }
            if (flag == 1)
            {
                if (P[0].X == 0)//墙边
                    return false;
                if (P[0].X == -3 || P[0].X == -2)
                    return true;
                if (m.map[P[1].X, P[1].Y-1] == 0)
                    return true;
            }
            if (flag == 2)
            {
                if (P[0].X == -2 || P[0].X == -1 || P[0].X == 0)
                    return true;
                if (m.map[P[1].X - 1, P[1].Y] == 0)
                    return true;
            }
            if (flag == 3)
            {
                if (P[0].X == -3)
                    return false;
                if (P[0].X == -2)
                    return true;
                if (m.map[P[2].X, P[2].Y + 1] == 0)
                    return true;
            }
            return false;
        }
        public override bool Can_Left(Map m)
        {
            if (flag == 0)
            {
                if (P[1].Y == 0)//左墙边
                    return false;
                if (P[0].X == -2)
                    return true;
                if (P[0].X == -1)
                {
                    if (m.map[P[1].X, P[1].Y - 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[0].X, P[0].Y - 1] == 0 && m.map[P[1].X, P[1].Y - 1] == 0)
                    return true;
            }
            if (flag == 1)
            {
                if (P[0].Y == 0)//左墙边
                    return false;
                if (P[0].X == -3)
                    return true;
                if (P[0].X == -2)
                {
                    if (m.map[P[3].X, P[3].Y - 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (P[0].X == -1)
                {
                    if (m.map[P[1].X, P[1].Y - 1] == 0 && m.map[P[3].X, P[3].Y - 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[0].X, P[0].Y - 1] == 0 && m.map[P[1].X, P[1].Y - 1] == 0 && m.map[P[3].X, P[3].Y - 1] == 0)
                    return true;
            }
            if (flag == 2)
            {
                if (P[0].Y == 0)//左墙边
                    return false;
                if (P[0].X == -2)
                    return true;
                if (P[0].X == -1)
                {
                    if (m.map[P[3].X, P[3].Y - 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[0].X, P[0].Y - 1] == 0 && m.map[P[3].X, P[3].Y - 1] == 0)
                    return true;
            }
            if (flag == 3)
            {
                if (P[1].Y == 0)//左墙边
                    return false;
                if (P[0].X == -3)
                    return true;
                if (P[0].X == -2)
                {
                    if (m.map[P[3].X, P[3].Y - 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (P[0].X == -1)
                {
                    if (m.map[P[1].X, P[1].Y - 1] == 0 && m.map[P[3].X, P[3].Y - 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[0].X, P[0].Y - 1] == 0 && m.map[P[1].X, P[1].Y - 1] == 0 && m.map[P[3].X, P[3].Y - 1] == 0)
                    return true;
            }
            return false;
        }
        public override bool Can_Right(Map m)
        {
            if (flag == 0)
            {
                if (P[3].Y == m.map.GetLength(1) - 1)//右墙边
                    return false;
                if (P[0].X == -2)
                    return true;
                if (P[0].X == -1)
                {
                    if (m.map[P[3].X, P[3].Y + 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[0].X, P[0].Y + 1] == 0 && m.map[P[3].X, P[3].Y + 1] == 0)
                    return true;
            }
            if (flag == 1)
            {
                if (P[2].Y == m.map.GetLength(1) - 1)//右墙边
                    return false;
                if (P[0].X == -3)
                    return true;
                if (P[0].X == -2)
                {
                    if (m.map[P[3].X, P[3].Y + 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (P[0].X == -1)
                {
                    if (m.map[P[2].X, P[2].Y + 1] == 0 && m.map[P[3].X, P[3].Y + 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[0].X, P[0].Y + 1] == 0 && m.map[P[2].X, P[2].Y + 1] == 0 && m.map[P[3].X, P[3].Y + 1] == 0)
                    return true;
            }
            if (flag == 2)
            {
                if (P[2].Y == m.map.GetLength(1) - 1)//右墙边
                    return false;
                if (P[0].X == -2)
                    return true;
                if (P[0].X == -1)
                {
                    if (m.map[P[3].X, P[3].Y + 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[2].X, P[2].Y + 1] == 0 && m.map[P[3].X, P[3].Y + 1] == 0)
                    return true;
            }
            if (flag == 3)
            {
                if (P[0].Y == m.map.GetLength(1) - 1)//右墙边
                    return false;
                if (P[0].X == -3)
                    return true;
                if (P[0].X == -2)
                {
                    if (m.map[P[3].X, P[3].Y + 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (P[0].X == -1)
                {
                    if (m.map[P[2].X, P[2].Y + 1] == 0 && m.map[P[3].X, P[3].Y + 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[0].X, P[0].Y + 1] == 0 && m.map[P[2].X, P[2].Y + 1] == 0 && m.map[P[3].X, P[3].Y + 1] == 0)
                    return true;
            }
            return false;
        }
        public override bool Can_Down(Map m)
        {
            if (flag == 0)
            {
                if (P[3].X == m.map.GetLength(0) - 1)//下墙边
                    return false;
                if (m.map[P[1].X + 1, P[1].Y] == 0 && m.map[P[2].X + 1, P[2].Y] == 0 && m.map[P[3].X + 1, P[3].Y] == 0)
                    return true;
            }
            if (flag == 1)
            {
                if (P[3].X == m.map.GetLength(0) - 1)//下墙边
                    return false;
                if (P[0].X == -3)
                {
                    if (m.map[P[3].X + 1, P[3].Y] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[P[3].X + 1, P[3].Y] == 0 && m.map[P[2].X + 1, P[2].Y] == 0)
                    return true;
            }
            if (flag == 2)
            {
                if (P[3].X == m.map.GetLength(0) - 1)//下墙边
                    return false;
                if (P[0].X == -2)
                {
                    if (m.map[P[3].X + 1, P[3].Y] == 0)
                        return true;
                }
                if (m.map[P[0].X + 1, P[0].Y] == 0 && m.map[P[2].X + 1, P[2].Y] == 0 && m.map[P[3].X + 1, P[3].Y] == 0)
                    return true;
            }
            if (flag == 3)
            {
                if (P[3].X == m.map.GetLength(0) - 1)//下墙边
                    return false;
                if (P[0].X == -3)
                {
                    if (m.map[P[3].X + 1, P[3].Y] == 0)
                        return true;
                }
                if (m.map[P[1].X + 1, P[1].Y] == 0 && m.map[P[3].X + 1, P[3].Y] == 0)
                    return true;
            }
            return false;
        }
        public override void Revolve(Map m)
        {
            if (flag == 0)
            {
                flag = 1;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 0;
                }
                P[0].X = P[3].X - 1; P[0].Y = P[3].Y - 1;
                P[1].X = P[3].X; P[1].Y = P[3].Y - 1;
                P[2].X = P[3].X; P[2].Y = P[3].Y;
                P[3].X = P[3].X + 1; P[3].Y = P[3].Y - 1;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 1;
                }
            }
            else if (flag == 1)
            {
                flag = 2;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 0;
                }
                P[0].X = P[3].X - 1; P[0].Y = P[3].Y - 1;
                P[1].X = P[3].X - 1; P[1].Y = P[3].Y;
                P[2].X = P[3].X - 1; P[2].Y = P[3].Y + 1;
                P[3].X = P[3].X; P[3].Y = P[3].Y;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 1;
                }
            }
            else if (flag == 2)
            {
                flag = 3;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 0;
                }
                P[0].X = P[3].X - 2; P[0].Y = P[3].Y;
                P[1].X = P[3].X - 1; P[1].Y = P[3].Y - 1;
                P[2].X = P[3].X - 1; P[2].Y = P[3].Y;
                P[3].X = P[3].X; P[3].Y = P[3].Y;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 1;
                }
            }
            else if (flag == 3)
            {
                flag = 0;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 0;
                }
                P[0].X = P[3].X - 2; P[0].Y = P[3].Y;
                P[1].X = P[3].X - 1; P[1].Y = P[3].Y - 1;
                P[2].X = P[3].X - 1; P[2].Y = P[3].Y;
                P[3].X = P[3].X - 1; P[3].Y = P[3].Y + 1;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 1;
                }
            }
        }
    }
}
