﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tetris
{
    public partial class Form1 : Form
    {
        bool ischecked;//判断只有在点击开始游戏或重新游戏之后，键盘上的按键才能有用。
        bool is_boxchange;//可以防止在切换Map由大到小时导致的超出数组界限
        public int x = 15, y = 10;
        int width, length;
        int speed;//speed为时间间隔，其越大，则方块下落越慢
        int score = 0;
        double time_num = 0;//计时
        string score_str;
        string time_num_str;
        int k;//k是是否满行的标记，满行为0，不满行为1
        public static Random r = new Random();
        int c_b = r.Next(1, 8);//随机选择方块
        public Map m;
        Blocks blocks;
        Blocks blocks_next;
        public Form1()
        {
            InitializeComponent();
        }

        public void Reset()
        {
            Graphics g = this.CreateGraphics();
            g.Clear(this.BackColor);
            width = 300 / y;
            length = 450 / x;
            for (int i = 0; i < m.map.GetLength(0); i++)
            {
                for (int j = 0; j < m.map.GetLength(1); j++)
                {
                    if (m.map[i, j] == 0)
                    {
                        g.FillRectangle(new SolidBrush(Color.White), j * length, i * width + 1, width - 1, length - 1);
                    }
                    else
                    {
                        g.FillRectangle(new SolidBrush(Color.Blue), j * length, i * width + 1, width - 1, length - 1);
                    }
                }
            }
        }

        public void Fill(Color c)
        {
            Graphics g = this.CreateGraphics();
            for (int i = 0; i < 4; i++)
                g.FillRectangle(new SolidBrush(c), blocks.P[i].Y * length, blocks.P[i].X * width + 1, width - 1, length - 1);
        }

        public void Creat_Blocks()
        {
            #region 测试单类方块代码
            //blocks = new Blocks_1(m);
            //blocks_next = new Blocks_1(m);
            #endregion
            if (blocks == null || is_boxchange)
                switch (r.Next(1, 8))
                {
                    case 1:
                        blocks = new Blocks_1(m);
                        break;
                    case 2:
                        blocks = new Blocks_2(m);
                        break;
                    case 3:
                        blocks = new Blocks_3(m);
                        break;
                    case 4:
                        blocks = new Blocks_4(m);
                        break;
                    case 5:
                        blocks = new Blocks_5(m);
                        break;
                    case 6:
                        blocks = new Blocks_6(m);
                        break;
                    case 7:
                        blocks = new Blocks_7(m);
                        break;
                }
            else
                blocks = blocks_next;
            switch (c_b)
            {
                case 1:
                    blocks_next = new Blocks_1(m);
                    break;
                case 2:
                    blocks_next = new Blocks_2(m);
                    break;
                case 3:
                    blocks_next = new Blocks_3(m);
                    break;
                case 4:
                    blocks_next = new Blocks_4(m);
                    break;
                case 5:
                    blocks_next = new Blocks_5(m);
                    break;
                case 6:
                    blocks_next = new Blocks_6(m);
                    break;
                case 7:
                    blocks_next = new Blocks_7(m);
                    break;
            }
            c_b = r.Next(1, 8);
        }

        public void Draw_Blocks()
        {
            Graphics g = this.CreateGraphics();
            g.FillRectangle(new SolidBrush(Color.White), 380, 100, 120, 120);
            switch (blocks_next.C_B)
            {
                case 10://"一"
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 470, 130, 29, 29);
                    break;
                case 11://"|"
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 100, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 190, 29, 29);
                    break;
                case 20://"田"
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    break;
                case 30://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 190, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 190, 29, 29);
                    break;
                case 31://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 470, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    break;
                case 32://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 190, 29, 29);
                    break;
                case 33://
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    break;
                case 40://
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 190, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 190, 29, 29);
                    break;
                case 41://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 470, 160, 29, 29);
                    break;
                case 42://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 190, 29, 29);
                    break;
                case 43://
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    break;
                case 50://
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    break;
                case 51://
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 190, 29, 29);
                    break;
                case 60://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    break;
                case 61://
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 190, 29, 29);
                    break;
                case 70://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    break;
                case 71://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    break;
                case 72://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 190, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 440, 160, 29, 29);
                    break;
                case 73://
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 130, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 410, 160, 29, 29);
                    g.FillRectangle(new SolidBrush(Color.Blue), 380, 160, 29, 29);
                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(textBox5.Text, out speed) || speed < 1 || speed > 1000)
                speed = 500;
            textBox5.Text = speed.ToString();
            timer2.Interval = speed;
            if (button1.Text == "重新游戏")
            {
                checkBox1.Enabled = false;
                checkBox2.Enabled = false;
                ischecked = true;
                timer1.Dispose();
                timer2.Dispose();
                time_num = 0;
                m.map = new int[x, y];
                Reset();
                Creat_Blocks();
                Draw_Blocks();
                button1.Text = "暂停游戏";
                timer1.Start();
                timer2.Start();
            }
            else if (button1.Text == "开始游戏")
            {
                checkBox1.Enabled = false;
                checkBox2.Enabled = false;
                button2.Visible = true;
                button2.Enabled = true;
                m = new Map(x, y);
                Reset();
                Creat_Blocks();
                Draw_Blocks();
                button1.Text = "暂停游戏";
                timer1.Start();
                timer2.Start();
                ischecked = true;
            }
            else if (button1.Text == "暂停游戏")
            {
                ischecked = false;
                button1.Text = "继续游戏";
                timer1.Stop();
                timer2.Stop();
            }
            else
            {
                ischecked = true;
                button1.Text = "暂停游戏";
                timer1.Start();
                timer2.Start();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            checkBox1.Enabled = true;
            checkBox2.Enabled = true; 
            ischecked = false;
            button2.Visible = false;
            button2.Enabled = false;
            timer1.Dispose();
            timer2.Dispose();
            time_num = 0;
            m.map = new int[x, y];
            Reset();
            Creat_Blocks();
            Graphics g = this.CreateGraphics();
            g.FillRectangle(new SolidBrush(Color.White), 380, 100, 120, 120);
            button1.Text = "开始游戏";
        }

        private void timer1_Tick(object sender, EventArgs e)//显示时间
        {
            time_num += 0.1;
            textBox1.Text = time_num.ToString("f1");
            #region 未搞定的理解
            //if (time_num == 0.7)//此处设置0.7及以下均可以暂停，设置0.8及以上则不能？？？
            //{
            //    MessageBox.Show(time_num.ToString());
            //    timer1.Dispose();
            //    timer2.Dispose();
            //    blocks.Revolve(m);
            //}
            #endregion
        }

        private void timer2_Tick(object sender, EventArgs e)//游戏开始
        {
            if (ischecked)
            {
                textBox2.Text = score.ToString();
                if (blocks.Can_Down(m))
                {
                    Fill(Color.White);
                    blocks.Down(m);
                    Fill(Color.Blue);
                }
                else if (blocks.P[0].X < 0)
                {
                    timer1.Dispose();
                    timer2.Dispose();
                    button1.Text = "重新游戏";
                    button1.BackColor = Color.Red;
                    score_str = score.ToString();
                    time_num_str = time_num.ToString("f1");
                    MessageBox.Show("您坚持了" + time_num_str + "秒!您的得分是" + score_str, "Game Over!!!");
                    checkBox1.Enabled = true;
                    checkBox2.Enabled = true;
                    button2.Enabled = false;
                    button2.Visible = false;
                }
                else
                {
                    score += 20;
                    Graphics g = this.CreateGraphics();
                    for (int num = 0; num < 4; num++)
                    {
                        for (int i = 0; i < m.map.GetLength(1); i++)
                        {
                            if (m.map[blocks.P[num].X, i] == 0)
                            {
                                k = 1;
                                break;
                            }
                            k = 0;
                        }
                        if (k == 0)//满行
                        {
                            score += 100;
                            k = 1;
                            for (int i = 0; i < m.map.GetLength(1); i++)
                            {
                                m.map[blocks.P[num].X, i] = 0;
                                g.FillRectangle(new SolidBrush(Color.White), i * length, blocks.P[num].X * width + 1, width - 1, length - 1);
                            }
                            for (int i = blocks.P[num].X; i >= 0; i--)//消除一行后，上面方块落下
                            {
                                for (int j = m.map.GetLength(1) - 1; j >= 0; j--)
                                {
                                    if (i != 0)
                                    {
                                        m.map[i, j] = m.map[i - 1, j];
                                        if (m.map[i, j] == 1)
                                        {
                                            g.FillRectangle(new SolidBrush(Color.Blue), j * length, i * width + 1, width - 1, length - 1);
                                        }
                                        else
                                        {
                                            g.FillRectangle(new SolidBrush(Color.White), j * length, i * width + 1, width - 1, length - 1);
                                        }
                                    }
                                    else
                                    {
                                        m.map[i, j] = 0;
                                        g.FillRectangle(new SolidBrush(Color.White), j * length, i * width + 1, width - 1, length - 1);
                                    }
                                }
                            }
                        }
                    }
                    Creat_Blocks();
                    Draw_Blocks();
                }
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            is_boxchange = true;
            if (checkBox1.Checked)
            {
                x = 15; y = 10;
                checkBox2.Checked = false;
            }
            else
            {
                x = 30; y = 20;
                checkBox2.Checked = true;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                x = 30; y = 20;
                checkBox1.Checked = false;
            }
            else
            {
                x = 15; y = 10;
                checkBox1.Checked = true;
            }
        }

        private void button1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (ischecked)
            {
                switch (e.KeyChar)
                {
                    case 'w':
                    case 'W':
                        if (blocks.Can_Revolve(m))
                        {
                            Fill(Color.White);
                            blocks.Revolve(m);
                            Fill(Color.Blue);
                        }
                        break;
                    case 'a':
                    case 'A':
                        if (blocks.Can_Left(m))
                        {
                            Fill(Color.White);
                            blocks.Left(m);
                            Fill(Color.Blue);
                        }
                        break;
                    case 'd':
                    case 'D':
                        if (blocks.Can_Right(m))
                        {
                            Fill(Color.White);
                            blocks.Right(m);
                            Fill(Color.Blue);
                        }
                        break;
                }
            }
        }

        private void button1_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.S:
                    timer2.Interval = speed / 10;
                    break;
            }
        }//按下S键加速方块下落

        private void button1_KeyUp(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.S:
                    timer2.Interval = speed;
                    break;
            }
        }//松开S键恢复方块原来下落速度
        #region 焦点问题
        //要想实现该方法必须使焦点在窗体上，而该程序需要点击开始游戏按钮，故焦点会在button上，
        //所以如果不设置焦点在窗体上，则无法实现该方法
        //private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //    switch (e.KeyChar)
        //    {
        //        case 'w':
        //        case 'W':
        //            if (blocks.Can_Revolve(m))
        //                blocks.Revolve(m);
        //            break;
        //    }
        //}
        #endregion
    }
}
