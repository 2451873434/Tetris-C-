﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    /// <summary>
    ///     我在Blocks的子类里将各个小方块的位置坐标用point代替。在方块集还未出现（即方块在Map之外）时定义其坐标为负值，
    /// 本想这可以简化Map的操作，但其实负值的存在导致方块集做各种运动（移动、旋转）时还要额外考虑方块为负坐标的情
    /// 况，因此加重了代码的繁琐程度。
    ///     解决办法：可以拓宽Map的行数（map.getlength(0)+4），但不画出最上面4行，修改程序终止条件为"在方块无法向下移
    /// 动的条件下，检查方块的横坐标位置，如果存在横坐标位置<=3的方块，则表示程序结束
    /// </summary>
    public class Blocks
    {
        Point[] p = new Point[4];
        int c_b;
        public Point[] P
        {
            get { return p; }
            set { p = value; }
        }
        public int C_B//作为标记下个方块的标识码
        {
            get { return c_b; }
            set { c_b = value; }
        }
        public virtual bool Can_Revolve(Map m)
        {
            return false;
        }
        public virtual bool Can_Left(Map m)
        {
            return false;
        }
        public virtual bool Can_Right(Map m)
        {
            return false;
        }
        public virtual bool Can_Down(Map m)
        {
            return false;
        }
        public virtual void Revolve(Map m)
        {

        }
        public void Left(Map m)
        {
            for (int i = 0; i < 4; i++)//先全部擦除
            {
                if (p[i].X >= 0)
                    m.map[p[i].X, p[i].Y] = 0;
                p[i].Y--;
            }
            for (int i = 0; i < 4; i++)//再填充颜色
                if (p[i].X >= 0)
                    m.map[p[i].X, p[i].Y] = 1;
        }
        public void Right(Map m)
        {
            for (int i = 0; i < 4; i++)//先全部擦除
            {
                if (p[i].X >= 0)
                    m.map[p[i].X, p[i].Y] = 0;
                p[i].Y++;
            }
            for (int i = 0; i < 4; i++)//再填充颜色
                if (p[i].X >= 0)
                    m.map[p[i].X, p[i].Y] = 1;
        }
        public void Down(Map m)
        {
            for (int i = 0; i < 4; i++)//先全部擦除
            {
                if(p[i].X>=0)
                    m.map[p[i].X, p[i].Y] = 0;
                p[i].X++;
            }
            for(int i=0;i<4;i++)//再填充颜色
                if (p[i].X >= 0)
                    m.map[p[i].X, p[i].Y] = 1;
            #region 错误代码
            //for (int i = 0; i < 4; i++)//一个一个擦除再填充,会导致在处理某些方块时操作p[3]时擦除了p[2]的填充（比如"|"形方块）
            //{
            //    if (p[i].X >= 0)
            //        m.map[p[i].X, p[i].Y] = 0;
            //    p[i].X++;
            //    if (p[i].X >= 0)
            //        m.map[p[i].X, p[i].Y] = 1;
            //}
            #endregion
        }




        //int randomID = 0;
        /*public void Change()
        {
            int[,] _blocks = new int[4, 4];
            blocks = _blocks;
            Random r = new Random();
            randomID = r.Next(0, 7);
            switch (randomID)
            {
                case 0://"一"
                    blocks[1, 0] = 1;
                    blocks[1, 1] = 1;
                    blocks[1, 2] = 1;
                    blocks[1, 3] = 1;
                    break;
                case 1://"田"
                    blocks[1, 1] = 1;
                    blocks[1, 2] = 1;
                    blocks[2, 1] = 1;
                    blocks[2, 2] = 1;
                    break;
                case 2://"L"
                    blocks[0, 1] = 1;
                    blocks[1, 1] = 1;
                    blocks[2, 1] = 1;
                    blocks[2, 2] = 1;
                    break;
                case 3://反"L"
                    blocks[0, 2] = 1;
                    blocks[1, 2] = 1;
                    blocks[2, 1] = 1;
                    blocks[2, 2] = 1;
                    break;
                case 4://"T"
                    blocks[1, 0] = 1;
                    blocks[1, 1] = 1;
                    blocks[1, 2] = 1;
                    blocks[2, 1] = 1;
                    break;
                case 5://"Z"
                    blocks[1, 0] = 1;
                    blocks[1, 1] = 1;
                    blocks[2, 1] = 1;
                    blocks[2, 2] = 1;
                    break;
                case 6://反"Z"
                    blocks[1, 1] = 1;
                    blocks[1, 2] = 1;
                    blocks[2, 0] = 1;
                    blocks[2, 1] = 1;
                    break;
            }
        }
        */
        /*public bool Can_Revolve()
        {
            switch(randomID)
            {
                case 0:

                    break;
            }
            return true;
        }
        */
        /*public void Revolve()
        {
            int[,] _blocks = new int[4, 4];
            for(int i=0;i<4;i++)
            {
                for(int j=0;j<4;j++)
                {
                    _blocks[i, j] = blocks[3 - j, i];
                }
            }
            blocks = _blocks;
        }
        */
    }
}
