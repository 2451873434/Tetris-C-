﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Tetris
{
    class Blocks_1 : Blocks//"一"和"|"形方块
    {
        int flag;
        public Blocks_1(Map m)
        {
            Random r = new Random();
            flag = r.Next(0,2);
            if (flag == 0)//"一"
            {
                C_B = 10;
                P[0].X = -1; P[0].Y = m.map.GetLength(1) / 2 - 2;
                P[1].X = -1; P[1].Y = m.map.GetLength(1) / 2 - 1;
                P[2].X = -1; P[2].Y = m.map.GetLength(1) / 2;
                P[3].X = -1; P[3].Y = m.map.GetLength(1) / 2 + 1;
            }
            else//"|"
            {
                C_B = 11;
                P[0].X = -4; P[0].Y = m.map.GetLength(1) / 2;
                P[1].X = -3; P[1].Y = m.map.GetLength(1) / 2;
                P[2].X = -2; P[2].Y = m.map.GetLength(1) / 2;
                P[3].X = -1; P[3].Y = m.map.GetLength(1) / 2;
            }
        }
        public override bool Can_Revolve(Map m)
        {
            if(flag==0)
            {
                if (this.P[0].X > m.map.GetLength(0) - 3)//方块在地图下边缘导致无法旋转
                    return false;
                if (P[0].X < 1 )
                {
                    if (m.map[P[3].X + 1, P[3].Y - 1] == 0 && m.map[P[3].X + 2, P[3].Y - 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (m.map[this.P[3].X - 1, this.P[3].Y - 1] == 0 &&
                    m.map[this.P[3].X + 1, this.P[3].Y - 1] == 0 &&
                    m.map[this.P[3].X + 2, this.P[3].Y - 1] == 0)//旋转后的目标位置未空白
                    return true;
            }
            else
            {
                if (P[3].Y == m.map.GetLength(1) - 1 || this.P[3].Y < 2)//方块在地图左右边缘导致无法旋转
                    return false;
                if (P[0].X < -2)//方块还未全部出现
                    return false;
                else if (P[0].X == -2)//特殊情况
                    return true;
                if (m.map[P[3].X - 2, P[3].Y - 2] == 0 &&
                    m.map[P[3].X - 2, P[3].Y - 1] == 0 &&
                    m.map[P[3].X - 2, P[3].Y + 1] == 0)//旋转后的目标位置未空白
                    return true;
            }
            #region 考虑方块存在阻碍的情况
            //if (m.map[this.P[0].X + 1, this.P[0].Y] == 1 ||
            //    m.map[this.P[0].X + 2, this.P[0].Y] == 1 ||
            //    m.map[this.P[1].X + 1, this.P[1].Y] == 1 ||
            //    m.map[this.P[1].X + 2, this.P[1].Y] == 1 ||
            //    m.map[this.P[3].X - 1, this.P[3].Y] == 1 )
            //    return false;
            #endregion
            return false;
        }
        public override bool Can_Left(Map m)
        {
            if (P[0].Y == 0)
                return false;
            if(flag==0)
            {
                if (P[0].X >= 0 && m.map[P[0].X, P[0].Y - 1] == 0)
                    return true;
            }
            else
            {
                if (P[0].X == -4)
                    return true;
                if (P[0].X == -3)
                {
                    if (m.map[P[3].X, P[3].Y - 1] == 0)
                        return true;
                    else
                        return false;
                }
                if (P[0].X == -2 && m.map[P[3].X, P[3].Y - 1] == 0 && m.map[P[3].X - 1, P[3].Y - 1] == 0)
                    return true;
                if (P[0].X == -1 &&
                   (m.map[P[3].X, P[3].Y - 1] == 0 &&
                    m.map[P[3].X - 1, P[3].Y - 1] == 0 &&
                    m.map[P[3].X - 2, P[3].Y - 1] == 0))
                    return false;
                if (m.map[P[3].X, P[3].Y - 1] == 0 &&
                    m.map[P[3].X - 1, P[3].Y - 1] == 0 &&
                    m.map[P[3].X - 2, P[3].Y - 1] == 0 &&
                    m.map[P[3].X - 3, P[3].Y - 1] == 0)
                    return true;
            }
            return false;
        }
        public override bool Can_Right(Map m)
        {
            if (P[3].Y == m.map.GetLength(1)-1)
                return false;
            if (flag == 0)
            {
                if (P[0].X >= 0 && m.map[P[3].X, P[3].Y + 1] == 0)
                    return true;
            }
            else
            {
                if (P[0].X == -4)
                    return true;
                if (P[0].X == -3 && m.map[P[3].X, P[3].Y + 1] == 0)
                    return true;
                if (P[0].X == -2 && m.map[P[3].X, P[3].Y + 1] == 0 && m.map[P[3].X - 1, P[3].Y + 1] == 0)
                    return true;
                if (P[0].X == -1 &&
                   (m.map[P[3].X, P[3].Y + 1] == 0 &&
                    m.map[P[3].X - 1, P[3].Y + 1] == 0 &&
                    m.map[P[3].X - 2, P[3].Y + 1] == 0))
                    return true;
                if (m.map[P[3].X, P[3].Y + 1] == 0 &&
                    m.map[P[3].X - 1, P[3].Y + 1] == 0 &&
                    m.map[P[3].X - 2, P[3].Y + 1] == 0 &&
                    m.map[P[3].X - 3, P[3].Y + 1] == 0)
                    return true;
            }
            return false;
        }
        public override bool Can_Down(Map m)
        {
            if (P[3].X == m.map.GetLength(0) - 1)
                return false;
            if (flag == 0)
            {
                if (m.map[P[0].X + 1, P[0].Y] == 0 &&
                    m.map[P[1].X + 1, P[1].Y] == 0 &&
                    m.map[P[2].X + 1, P[2].Y] == 0 &&
                    m.map[P[3].X + 1, P[3].Y] == 0)
                    return true;
            } 
            if (flag==1)
            {
                if (m.map[P[3].X + 1, P[3].Y] == 0)
                    return true;
            }
                return false;
        }
        public override void Revolve(Map m)
        {
            if (flag == 0)
            {
                flag = 1;
                for (int i = 0; i < 4; i++)
                {
                    if(P[i].X>=0)
                        m.map[this.P[i].X, this.P[i].Y] = 0;
                }
                P[0].X = P[3].X - 1; P[0].Y = P[3].Y - 1;
                P[1].X = P[3].X;     P[1].Y = P[3].Y - 1;
                P[2].X = P[3].X + 1; P[2].Y = P[3].Y - 1;
                P[3].X = P[3].X + 2; P[3].Y = P[3].Y - 1;
                for (int i = 0; i < 4; i++)
                {
                    if(P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 1;
                }
            }
            else
            {
                flag = 0;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 0;
                }
                this.P[0].X = this.P[3].X - 2; this.P[0].Y = this.P[3].Y - 2;
                this.P[1].X = this.P[3].X - 2; this.P[1].Y = this.P[3].Y - 1;
                this.P[2].X = this.P[3].X - 2; this.P[2].Y = this.P[3].Y;
                this.P[3].X = this.P[3].X - 2; this.P[3].Y = this.P[3].Y + 1;
                for (int i = 0; i < 4; i++)
                {
                    if (P[i].X >= 0)
                        m.map[this.P[i].X, this.P[i].Y] = 1;
                }
            }
        }

    }
}
